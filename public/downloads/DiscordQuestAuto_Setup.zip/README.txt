========================================================================
         J3A DISCORD AUTOQUEST - INSTALLATION & USER GUIDE
         คู่มือการติดตั้งและใช้งานระบบ (THAI / ENGLISH)
         Version: 2.8.1 | J3A Software Solutions
========================================================================

------------------------------------------------------------------------
 [TH] ภาษาไทย: คู่มือการติดตั้งและเริ่มต้นใช้งาน
------------------------------------------------------------------------

[1] เกี่ยวกับโปรแกรม
J3A Discord AutoQuest คือระบบจัดการทำเควสต์ Discord แบบอัตโนมัติบนเครื่องของคุณเอง
(Local Automation Engine) ช่วยทำเควสต์ดูวิดีโอ (Watch Video) และเควสต์เกมโดยไม่ต้อง
เปิดคลิปแช่หรือดาวน์โหลดเกมขนาดใหญ่ ปลอดภัยสูงสุดด้วย Safe Mode (No AutoClaim)
เพื่อป้องกันการตรวจจับ และมีระบบคำนวณ Discord Orbs แบบเรียลไทม์

[2] นโยบายสิทธิ์การใช้งาน (License Agreement & HWID Lock)
• 1 License Key ใช้ได้กับคอมพิวเตอร์ 1 เครื่องเท่านั้น (ผูกสิทธิ์ผ่านรหัสอุปกรณ์ HWID อัตโนมัติ)
• รองรับแพ็กเกจคีย์ดังต่อไปนี้:
  - DAQ-3D- : คีย์ 3 วัน (สำหรับทดลอง / ซื้อครั้งแรก 72 ชม.) *จำกัด 1 ครั้งต่อเครื่อง*
  - DAQ-1W- : คีย์ 1 สัปดาห์ (7 วัน)
  - DAQ-4W- : คีย์ 4 สัปดาห์ (28 วัน)
  - DAQ-6M- : คีย์ 6 เดือน (180 วัน)
• สั่งซื้อหรือต่ออายุคีย์ได้ที่: https://j3a-store.vercel.app

[3] ความต้องการของระบบ (System Requirements)
• ระบบปฏิบัติการ: Windows 10 หรือ Windows 11 (64-bit เท่านั้น)
• Node.js: แนะนำเวอร์ชัน 18 ขึ้นไป (ดาวน์โหลดฟรีได้ที่ https://nodejs.org)
• เว็บบราวเซอร์: Google Chrome หรือ Microsoft Edge (สำหรับรัน Standalone Window Mode)
• การเชื่อมต่ออินเทอร์เน็ตที่เสถียร

[4] ขั้นตอนการติดตั้ง (Installation Steps)
1. ทำการแตกไฟล์ "DiscordQuestAuto_Setup.zip" (คลิกขวา -> Extract All... หรือ แยกไฟล์ที่นี่)
2. ดับเบิ้ลคลิกเปิดไฟล์ "Setup.exe"

   ⚠️ ทำไม Windows ถึงขึ้นเตือน "Windows protected your PC" (SmartScreen)?
   - สาเหตุ: ตัวไฟล์ Setup.exe เป็นตัวคอมไพล์เวอร์ชันใหม่ (New Release Build) ทำให้ระบบ 
     Cloud Telemetry ของ Microsoft ยังไม่สะสมยอดการดาวน์โหลดนับหมื่นครั้ง (Reputation Score) 
     และเนื่องจากไม่ได้ซื้อใบรับรอง EV Code-Signing Certificate รายปีราคาหลักหมื่นบาท 
     ระบบ Windows Defender SmartScreen จึงแสดงหน้าต่างสีฟ้าแจ้งเตือนตามมาตรฐานความปลอดภัย
   - ยืนยันความปลอดภัย: ตัวโปรแกรมทำงานเป็น Localhost Engine (127.0.0.1) ในเครื่องของคุณเอง 100% 
     ไม่มีการส่ง Token หรือข้อมูลส่วนตัวใดๆ ออกภายนอก และไม่มีมัลแวร์แน่นอน
   - วิธีการเปิดใช้งาน:
     1) ในหน้าต่างสีฟ้า ให้คลิกที่ข้อความ "More info" (ข้อมูลเพิ่มเติม)
     2) จะปรากฏปุ่ม "Run anyway" (เรียกใช้ต่อไป) ที่มุมล่างขวา ให้คลิกปุ่มนี้เพื่อเริ่มติดตั้งทันที

3. เลือกตำแหน่งโฟลเดอร์ที่ต้องการติดตั้ง (หรือใช้ตำแหน่งเริ่มต้นตามที่แนะนำ)
4. ติ๊กเครื่องหมายถูกเพื่อยอมรับเงื่อนไข แล้วกดปุ่ม "Install"
5. เมื่อติดตั้งเสร็จสมบูรณ์ สามารถกด "Launch Now" ได้ทันที 
   (ตัวโปรแกรมจะสร้าง Shortcut ไอคอนไว้ที่หน้า Desktop และ Start Menu ให้โดยอัตโนมัติ)

[5] การเปิดใช้งานและการกรอก License Key ครั้งแรก
1. เปิดโปรแกรมจากไอคอน "Discord Quest Auto" บนหน้า Desktop
2. ระบบจะตรวจสอบสิทธิ์และแสดงหน้าต่างขอรับ License Key
3. นำคีย์ที่คุณได้รับจากการสั่งซื้อ (ขึ้นต้นด้วย J3ADQ-) มาวางลงในช่องกรอก
4. กดปุ่ม "ยืนยันและเปิดใช้งาน (Activate)" ระบบจะทำการผูกสิทธิ์กับเครื่องของคุณทันที
5. หลังจากยืนยันสำเร็จ โปรแกรมจะพาคุณเข้าสู่หน้าแดชบอร์ดหลักเพื่อเริ่มใช้งาน


========================================================================
 [EN] ENGLISH: Installation & Quick Start Guide
========================================================================

[1] About J3A Discord AutoQuest
J3A Discord AutoQuest is a local automation engine that helps you complete Discord
Quests seamlessly on your own PC. It automates video watching quests and game activities
without having to play videos in real-time or download massive game clients. Built with
Safe Mode (No AutoClaim) to prevent captchas and rate limits, featuring real-time
Discord Orbs calculation and multi-account switcher.

[2] License Policy & HWID Lock
• 1 License Key is bound strictly to 1 Computer (Hardware ID Lock).
• All valid license keys for this software must begin with the "J3ADQ-" prefix.
• Keys for other J3A software (such as J3ADM- or J3ADP-) cannot be used.

[3] System Requirements
• Operating System: Windows 10 / Windows 11 (64-bit)
• Runtime: Node.js v18 or later (Download free at https://nodejs.org)
• Browser: Google Chrome or Microsoft Edge (used for Standalone App Mode)
• An active internet connection

[4] Installation Steps
1. Extract "DiscordQuestAuto_Setup.zip" to a folder of your choice.
2. Double-click and run "Setup.exe".
   💡 Note: If Windows Defender prompts "Security scan required (up to 10 seconds)",
   this is a standard initial check for freshly built applications. It is 100% safe.
   If SmartScreen appears, click "More info" -> "Run anyway".
3. Select your installation directory (or use the recommended default path).
4. Check the agreement box and click "Install".
5. Once installation finishes, click "Launch Now". Desktop and Start Menu shortcuts
   will be created automatically.

[5] First-Time Activation
1. Launch "Discord Quest Auto" from your Desktop shortcut.
2. The license activation prompt will appear displaying your machine's HWID.
3. Paste the License Key you received upon purchase (must start with "J3ADQ-").
4. Click "ยืนยันและเปิดใช้งาน (Activate)" to bind the key to your machine.
5. Once verified, you will be redirected to the main automation dashboard.

========================================================================
 Support & Inquiries: ติดต่อฝ่ายบริการและสอบถามข้อมูลเพิ่มเติม
 Discord Community / Support Ticket: ทักแอดมินหรือเปิด Ticket ในเซิร์ฟเวอร์
========================================================================