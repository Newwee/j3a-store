J3A Discord Profile - Official Release
=====================================
1) Open J3ADiscordProfile.exe
2) Enter your License Key obtained from J3ASTORE
3) Enter your Discord Developer Application ID and enjoy!
